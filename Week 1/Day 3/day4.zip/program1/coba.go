package main

import (
	"fmt"
	"math"
)

func main() {
	fmt.Println(math.Sqrt(1000000007))
	fmt.Println(math.Sqrt(31622.77671236351))
	fmt.Println(math.Sqrt(177.82794131509118))
	fmt.Println(math.Sqrt(13.335214333301552))
}
